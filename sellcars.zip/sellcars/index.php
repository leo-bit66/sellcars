<?php

// Extract HTTP method and request URI
$request_method = $_SERVER['REQUEST_METHOD'];
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

$base_url = "/sellcars";
// Remove the base URL from the request URI
$uri = str_replace($base_url, '', $request_uri);
$routes = [
    '/' => 'frontend/login.php',
    '/index.php' => 'frontend/login.php',
    '/customers-page' => 'frontend/customers.php',
        // Add more routes as needed
];

if (array_key_exists($uri, $routes)) {
    require_once $routes[$uri]; // Route requests to the appropriate file
} else {
    http_response_code(404);
    header("HTTP/1.0 404 Not Found");
    echo '404 Not Found';
}