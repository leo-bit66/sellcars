document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const modal = document.getElementById('error-modal');
    const modalMessage = document.getElementById('modal-message');

    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const formData = new FormData(loginForm);

        try {
            const baseUrl = window.location.origin;
            const loginUrl = `${baseUrl}/sellcars/backend/login.php`;
            const response = await fetch(loginUrl, {
                method: 'POST',
                body: formData,
            });

            const data = await response.json();
            if (data.status === 'success') {
                handleSuccessfulLogin(data.message);
            } else {
                handleFailedLogin(data.message);
            }
        } catch (error) {
            console.error('An error occurred during the fetch operation:', error);
        }
    });

    function handleSuccessfulLogin(message) {
        const baseUrl = window.location.origin;
        const customersPageURL = `${baseUrl}/sellcars/customers-page`;
        window.location.href = customersPageURL;
        console.log(message);
    }
    
    function handleFailedLogin(errorMessage) {
        // Display the error message in the modal
        modalMessage.textContent = `Login Failed: ${errorMessage}`;
        modal.style.display = 'block';
    }

    const closeButton = document.querySelector('.close');
    if (closeButton) {
        closeButton.style.display = 'block';
        closeButton.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});