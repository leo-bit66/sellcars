<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/sellcars/frontend/css/login-styles.css">
        <link rel="icon" href="/sellcars/frontend/favicon.ico" type="image/x-icon">
        <title>SellCars Login</title>
    </head>
    <body>
        <div class="login-container">
            <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 20px;">
                <img src="/sellcars/frontend/logo.png" alt="Logo">
            </div>
            <form class="login-form" id="login-form">
                <div class="form-group">
                    <label for="username">Username:&nbsp;</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:&nbsp;</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                <button type="submit">Login</button>
            </form>
        </div>

        <div id="error-modal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <p id="modal-message"></p>
            </div>
        </div>

        <script src="/sellcars/frontend/js/login.js"></script>
    </body>
</html>