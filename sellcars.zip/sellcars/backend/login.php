<?php

// Include the database connection file
include __DIR__ . '/../backend/config/database.php';

// Start a PHP session
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = isset($_POST["username"]) ? $conn->real_escape_string($_POST["username"]) : "";
    $password = isset($_POST["password"]) ? $_POST["password"] : "";

    $query = "SELECT * FROM users WHERE email = '$username'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $hashedPasswordFromDatabase = $user['password_hash'];

        if (md5(trim($password)) === $hashedPasswordFromDatabase) {

            $userId = $user['id'];
            $updateQuery = "UPDATE users SET updated_at = NOW() WHERE id = $userId";
            $conn->query($updateQuery);

            $_SESSION['user_id'] = $userId;
            $_SESSION['customer_name'] = $user['first_name'] . ' ' . $user['last_name'];
            $_SESSION['last_login'] = $user['updated_at'];

            $response = array("status" => "success", "message" => "Login successful");
        } else {
            // Failed login
            $response = array("status" => "error", "message" => "Invalid credentials");
        }
    } else {
        // User not found
        $response = array("status" => "error", "message" => "User not found");
    }

    header('Content-Type: application/json');
    echo json_encode($response);

    $conn->close();
} else {
    header("HTTP/1.1 405 Method Not Allowed");
    echo "Method Not Allowed";
}