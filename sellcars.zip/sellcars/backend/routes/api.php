<?php

include __DIR__ . '/../config/database.php';
include_once __DIR__ . '/../controllers/CustomerController.php';

$route = isset($_GET['route']) ? $_GET['route'] : '';
$controller = new CustomerController($conn);

switch ($route) {
    case 'upload':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->handleFileUpload($_GET['type']);
        } else {
            // TODO
        }
        break;
    case 'get-customer':
    case 'update-customer':
    case 'delete-customer':
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $controller->getCustomer($_GET['id']);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $controller->updateCustomer($_GET['id']);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $controller->deleteCustomer($_GET['id']);
        }
        break;

    default:
        // Handle invalid routes
        header("HTTP/1.0 404 Not Found");
        echo '404 Not Found';
        break;
}