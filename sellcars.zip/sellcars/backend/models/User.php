<?php

class User {
    public static function validateLogin($email, $password) {
        // Implement your logic to validate user credentials
    }
}