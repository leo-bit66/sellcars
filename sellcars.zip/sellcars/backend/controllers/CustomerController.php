<?php

include_once __DIR__ . '/../models/CSVFileUploader.php';
include_once __DIR__ . '/../models/Customer.php';

class CustomerController {

    private $csvFileUploader;
    private $customerHandler;

    public function __construct($conn) {
        $this->csvFileUploader = new CSVFileUploader($conn);
        $this->customerHandler = new Customer($conn);
    }

    public function handleFileUpload($uploadType) {
        try {
            // Validate upload type
            $allowedTypes = ['customers', 'contact_persons', 'addresses'];
            if (!in_array($uploadType, $allowedTypes)) {
                throw new Exception('Invalid upload type.');
            }
            // Check if the file is set and not empty
            if (!isset($_FILES["csvFile"]) || empty($_FILES["csvFile"]["name"])) {
                throw new Exception('No file uploaded or the file is empty.');
            }
            
            $csvFile = $_FILES["csvFile"]["tmp_name"];

            // Handle file upload based on the specified type
            switch ($uploadType) {
                case 'customers':
                    $this->csvFileUploader->uploadCustomers($csvFile);
                    break;
                case 'contact_persons':
                    $this->csvFileUploader->uploadContactPersons($csvFile);
                    break;
                case 'addresses':
                    $this->csvFileUploader->uploadAddresses($csvFile);
                    break;
                default:
                    throw new Exception('Invalid upload type.');
            }

            // Return success response
            $response = ['status' => 'success', 'message' => 'File uploaded successfully.'];
            echo json_encode($response);
        } catch (Exception $e) {
            // Return error response
            $response = ['status' => 'error', 'message' => $e->getMessage()];
            echo json_encode($response);
        }
    }

    public function getCustomer($customerId) {
        $customerData = $this->customerHandler->getCustomerById($customerId);
        // Check if customer data is retrieved successfully
        if ($customerData !== false) {
            header('Content-Type: application/json');
            echo json_encode($customerData, JSON_PRETTY_PRINT);
        } else {
            echo json_encode(['error' => 'Customer not found']);
        }
    }
    
    public function createCustomer() {
        
    }

    public function updateCustomer($customerId) {
        
        $data = json_decode(file_get_contents('php://input'), true);
        $result = $this->customerHandler->updateCustomer($customerId, $data);
        echo json_encode($result);
    }
    
    public function deleteCustomer($customerId) {
        $result = $this->customerHandler->deleteCustomer($customerId);
        echo json_encode($result);
    }

}
